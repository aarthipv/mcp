--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5 (Postgres.app)
-- Dumped by pg_dump version 17.5 (Postgres.app)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE aarthiprashanth;
--
-- Name: aarthiprashanth; Type: DATABASE; Schema: -; Owner: aarthiprashanth
--

CREATE DATABASE aarthiprashanth WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = icu LOCALE = 'en_US.UTF-8' ICU_LOCALE = 'en-US';


ALTER DATABASE aarthiprashanth OWNER TO aarthiprashanth;

\connect aarthiprashanth

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: employee_leaves; Type: TABLE; Schema: public; Owner: aarthiprashanth
--

CREATE TABLE public.employee_leaves (
    emp_id character varying(10) NOT NULL,
    balance integer NOT NULL
);


ALTER TABLE public.employee_leaves OWNER TO aarthiprashanth;

--
-- Name: leave_history; Type: TABLE; Schema: public; Owner: aarthiprashanth
--

CREATE TABLE public.leave_history (
    id integer NOT NULL,
    emp_id character varying(10),
    leave_date date NOT NULL
);


ALTER TABLE public.leave_history OWNER TO aarthiprashanth;

--
-- Name: leave_history_id_seq; Type: SEQUENCE; Schema: public; Owner: aarthiprashanth
--

CREATE SEQUENCE public.leave_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.leave_history_id_seq OWNER TO aarthiprashanth;

--
-- Name: leave_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: aarthiprashanth
--

ALTER SEQUENCE public.leave_history_id_seq OWNED BY public.leave_history.id;


--
-- Name: leave_history id; Type: DEFAULT; Schema: public; Owner: aarthiprashanth
--

ALTER TABLE ONLY public.leave_history ALTER COLUMN id SET DEFAULT nextval('public.leave_history_id_seq'::regclass);


--
-- Data for Name: employee_leaves; Type: TABLE DATA; Schema: public; Owner: aarthiprashanth
--

COPY public.employee_leaves (emp_id, balance) FROM stdin;
\.
COPY public.employee_leaves (emp_id, balance) FROM '$$PATH$$/3673.dat';

--
-- Data for Name: leave_history; Type: TABLE DATA; Schema: public; Owner: aarthiprashanth
--

COPY public.leave_history (id, emp_id, leave_date) FROM stdin;
\.
COPY public.leave_history (id, emp_id, leave_date) FROM '$$PATH$$/3675.dat';

--
-- Name: leave_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: aarthiprashanth
--

SELECT pg_catalog.setval('public.leave_history_id_seq', 10, true);


--
-- Name: employee_leaves employee_leaves_pkey; Type: CONSTRAINT; Schema: public; Owner: aarthiprashanth
--

ALTER TABLE ONLY public.employee_leaves
    ADD CONSTRAINT employee_leaves_pkey PRIMARY KEY (emp_id);


--
-- Name: leave_history leave_history_pkey; Type: CONSTRAINT; Schema: public; Owner: aarthiprashanth
--

ALTER TABLE ONLY public.leave_history
    ADD CONSTRAINT leave_history_pkey PRIMARY KEY (id);


--
-- Name: leave_history leave_history_emp_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aarthiprashanth
--

ALTER TABLE ONLY public.leave_history
    ADD CONSTRAINT leave_history_emp_id_fkey FOREIGN KEY (emp_id) REFERENCES public.employee_leaves(emp_id);


--
-- PostgreSQL database dump complete
--

